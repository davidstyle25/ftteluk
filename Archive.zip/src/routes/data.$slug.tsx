import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Download, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { AppLayout } from "@/components/AppLayout";
import { DataTableView, exportTableCsv } from "@/components/DataTableView";
import { ExcelUploadDialog } from "@/components/ExcelUploadDialog";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { PivotMutasiView } from "@/components/PivotMutasiView";
import { ProduktivitasRmftView } from "@/components/ProduktivitasRmftView";
import { AverageGiroView } from "@/components/AverageGiroView";
import { EdcQrisView, PROD_CFG, SV_CFG } from "@/components/EdcQrisView";
import { TimeSeriesView } from "@/components/TimeSeriesView";
import { CategoryStats } from "@/components/CategoryStats";
import { EdcProduktifTable } from "@/components/EdcProduktifTable";
import { ValasGiroCard } from "@/components/ValasGiroCard";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { CATEGORY_BY_SLUG } from "@/lib/data-catalog";
import { useRole } from "@/lib/use-role";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/data/$slug")({
  head: () => ({
    meta: [
      { title: "Detail Kategori Data — BO Teluk Betung" },
      {
        name: "description",
        content: "Lihat, cari, dan ekspor catatan data kategori terpilih di BO Teluk Betung.",
      },
      { property: "og:title", content: "Detail Kategori Data — BO Teluk Betung" },
      {
        property: "og:description",
        content: "Lihat, cari, dan ekspor catatan data kategori terpilih.",
      },
    ],
  }),
  component: DataCategoryPage,
});

function useCount(table: string, tick: number) {
  const [count, setCount] = useState<number | null>(null);
  useEffect(() => {
    setCount(null);
    supabase
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .from(table as any)
      .select("*", { count: "exact", head: true })
      .then(({ count: c }) => setCount(c ?? 0));
  }, [table, tick]);
  return count;
}

function DataCategoryPage() {
  const { slug } = Route.useParams();
  const category = CATEGORY_BY_SLUG.get(slug);
  const { isAdmin, isFullAdmin, role: userRole } = useRole();
  const [tick, setTick] = useState(0);
  const [tab, setTab] = useState<"data" | "pivot">("data");
  const [confirmWipe, setConfirmWipe] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [csvOpen, setCsvOpen] = useState(false);
  const [periods, setPeriods] = useState<Record<string, string>>({});
  // Menu EDC dan QRIS (tanpa submenu) menampilkan data dari DATA3 DTD masing-masing.
  const dataTable =
    slug === "edc"
      ? "data_edc_data3"
      : slug === "qris"
        ? "data_qris_data3"
        : (category?.table ?? "settings");
  const count = useCount(dataTable, tick);

  // Untuk kategori hasil compare (MTD/YTD/DTD TAB & GIRO), tampilkan periode sumber
  // pada header tgl1/tgl2 alih-alih label statis.
  useEffect(() => {
    const map: Record<string, { src: string; base: string }> = {
      mtd_tab: { src: "data_di319_data2", base: "data_di319_data3" },
      ytd_tab: { src: "data_di319_data1", base: "data_di319_data3" },
      mtd_giro: { src: "data_di321_data2", base: "data_di321_data3" },
      ytd_giro: { src: "data_di321_data1", base: "data_di321_data3" },
      dtd_tab: { src: "data_di319_data4", base: "data_di319_data3" },
      dtd_giro: { src: "data_di321_data4", base: "data_di321_data3" },
    };
    const cfg = map[slug];
    if (!cfg) {
      setPeriods({});
      return;
    }
    let cancelled = false;
    (async () => {
      const fetchPeriode = async (table: string): Promise<string> => {
        const { data, error } = await supabase
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          .from(table as any)
          .select("periode")
          .limit(1);
        if (error) return "";
        const rows = (data ?? []) as unknown as Record<string, unknown>[];
        return String(rows[0]?.["periode"] ?? "");
      };
      const [p1, p2] = await Promise.all([fetchPeriode(cfg.src), fetchPeriode(cfg.base)]);
      if (!cancelled) setPeriods({ tgl1: p1, tgl2: p2 });
    })();
    return () => {
      cancelled = true;
    };
  }, [slug]);

  // Administrator 2 tidak boleh membuka halaman RKA (menunggu role selesai dimuat).
  if (category?.group === "RKA" && userRole && !isFullAdmin) {
    return (
      <AppLayout>
        <p className="text-sm text-muted-foreground">Anda tidak memiliki akses ke menu RKA.</p>
      </AppLayout>
    );
  }

  if (!category) {
    return (
      <AppLayout>
        <p className="text-sm text-muted-foreground">Kategori tidak ditemukan.</p>
      </AppLayout>
    );
  }

  const isCompareResult = category.readonly && !!CATEGORY_BY_SLUG.get(`${slug}_kenaikan`);
  const isProduktivitas = slug === "produktivitas_rmft";
  const isTimeSeries = slug === "time_series";
  // DATA1 YTD / DATA2 MTD / DATA3 DTD / DATA4 KEMARIN milik DI321: tampilkan tabel kurs Valas Giro.
  const isDi321 = /^di321_data[1-4]$/.test(slug);
  // Tabel Valas Giro hanya untuk admin; viewer tidak melihatnya.
  const showValas = isDi321 && isAdmin;
  // Viewer hanya punya akses penuh di kategori Pivot Multi; selainnya read-only.
  const canManage = isAdmin || slug === "pivot_multi";

  // Server membatasi satu permintaan (default 1000 baris), jadi ambil bertahap per 1000 baris
  // berurutan berdasarkan id sampai habis, supaya semua data ikut ter-export.
  const fetchAllRows = async (table: string): Promise<Record<string, unknown>[] | null> => {
    const all: Record<string, unknown>[] = [];
    const chunk = 1000;
    for (let i = 0; i < 1000; i++) {
      const { data, error } = await supabase
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        .from(table as any)
        .select("*")
        .order("id", { ascending: true })
        .range(i * chunk, i * chunk + chunk - 1);
      if (error) {
        toast.error(`Export gagal: ${error.message}`);
        return null;
      }
      const part = (data ?? []) as unknown as Record<string, unknown>[];
      all.push(...part);
      if (part.length < chunk) break;
    }
    return all;
  };

  // Halaman hasil compare: satu sheet seperti file nominatif MTD/YTD.
  // Blok atas "TURUN" (DELTA <= -100 juta, terbesar dulu), blok bawah "NAIK" (DELTA >= 100 juta).
  const exportCompare = async () => {
    const LIMIT = 100_000_000;
    const h1 = periods["tgl1"] || "tgl 1";
    const h2 = periods["tgl2"] || "tgl 2";
    const jenis = /tab$/.test(slug) ? "TABUNGAN" : "GIRO";
    const toNum = (v: unknown) => {
      const n = Number(String(v ?? "").replace(/[^0-9.-]/g, ""));
      return Number.isFinite(n) ? n : 0;
    };
    type Item = { norek: string; nama: string; v1: number; v2: number; rm: string };
    const load = async (kind: "kenaikan" | "penurunan"): Promise<Item[] | null> => {
      const data = await fetchAllRows(`${dataTable}_${kind}`);
      if (!data) return null;
      return data.map((r) => ({
        norek: String(r["norek"] ?? ""),
        nama: String(r["nama_nasabah"] ?? "").trim(),
        v1: toNum(r["tgl1"]),
        v2: toNum(r["tgl2"]),
        rm: String(r["rm_pengelola"] ?? ""),
      }));
    };
    const up = await load("kenaikan");
    const down = await load("penurunan");
    if (!up || !down) return;
    const delta = (x: Item) => Math.round((x.v2 - x.v1) * 100) / 100;
    const turun = down.filter((x) => delta(x) <= -LIMIT).sort((x, y) => delta(x) - delta(y));
    const naik = up.filter((x) => delta(x) >= LIMIT).sort((x, y) => delta(y) - delta(x));
    if (turun.length === 0 && naik.length === 0) {
      toast.error(
        up.length + down.length === 0
          ? "Tidak ada data. Jalankan Compare Data lebih dulu."
          : "Tidak ada rekening dengan DELTA di atas 100 juta.",
      );
      return;
    }

    const XLSX = await import("xlsx");
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const ws: Record<string, any> = {};
    const merges: { s: { r: number; c: number }; e: { r: number; c: number } }[] = [];
    const NUM_FMT = '_-* #,##0.00_-;\\-* #,##0.00_-;_-* "-"??_-;_-@_-';
    const put = (r: number, c: number, cell: Record<string, unknown>) => {
      ws[XLSX.utils.encode_cell({ r: r - 1, c: c - 1 })] = cell;
    };
    const str = (v: string) => ({ t: "s", v });
    const num = (v: number, f?: string) => ({ t: "n", v, z: NUM_FMT, ...(f ? { f } : {}) });

    let row = 1;
    const block = (title: string, items: Item[]) => {
      put(row, 1, str(title));
      merges.push({ s: { r: row - 1, c: 0 }, e: { r: row - 1, c: 6 } });
      row += 1;
      ["NO", "Norek", "NAMA NASABAH", h1, h2, "DELTA", "RM PENGELOLA"].forEach((h, i) =>
        put(row, i + 1, str(h)),
      );
      row += 1;
      const first = row;
      items.forEach((x, i) => {
        put(row, 1, { t: "n", v: i + 1 });
        put(row, 2, str(x.norek));
        put(row, 3, str(x.nama));
        put(row, 4, num(x.v1));
        put(row, 5, num(x.v2));
        put(row, 6, num(delta(x), `E${row}-D${row}`));
        put(row, 7, str(x.rm));
        row += 1;
      });
      const last = row - 1;
      put(row, 1, str("Total"));
      if (items.length > 0) {
        put(row, 4, num(items.reduce((a, x) => a + x.v1, 0), `SUM(D${first}:D${last})`));
        put(row, 5, num(items.reduce((a, x) => a + x.v2, 0), `SUM(E${first}:E${last})`));
        put(row, 6, num(items.reduce((a, x) => a + delta(x), 0), `SUM(F${first}:F${last})`));
      }
      row += 3; // dua baris kosong antar blok
    };
    block(`${jenis} TURUN KC`, turun);
    block(`${jenis} NAIK KC`, naik);

    ws["!ref"] = XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: row - 3, c: 6 } });
    ws["!merges"] = merges;
    ws["!cols"] = [{ wch: 5 }, { wch: 20 }, { wch: 28 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 32 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, category.label.slice(0, 31));
    XLSX.writeFile(wb, `${slug}.xlsx`);
  };

  const exportExcel = async () => {
    if (isCompareResult) {
      await exportCompare();
      return;
    }
    const all = await fetchAllRows(dataTable);
    if (!all) return;
    // Kolom internal balance_asli (balance sebelum dikali kurs) dan balance_num (untuk urut angka) tidak ikut di file.
    const rows = all.map((r) => {
      const { balance_asli: _asli, balance_num: _num, ...rest } = r;
      void _asli;
      void _num;
      return rest;
    });
    exportTableCsv(rows, `${slug}.xlsx`);
  };

  const wipe = async () => {
    // Halaman hasil compare (MTD/YTD/DTD GIRO & TAB) menampilkan tabel Kenaikan & Penurunan,
    // jadi yang dihapus adalah kedua tabel itu (tabel induknya memang kosong).
    const targets = isCompareResult
      ? [`${dataTable}_kenaikan`, `${dataTable}_penurunan`]
      : [dataTable];
    let failed: string | null = null;
    for (const t of targets) {
      const { error } = await supabase
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        .from(t as any)
        .delete()
        .gte("id", 0);
      if (error) {
        failed = error.message;
        break;
      }
    }
    setConfirmWipe(false);
    if (failed) {
      toast.error(failed);
      return;
    }
    toast.success("Semua data dihapus.");
    setTick((t) => t + 1);
  };

  return (
    <AppLayout>
      <PageHeader
        title={category.label}
        description="Manage data records for this category."
        actions={
          isTimeSeries ? null : (
          <>
            <Button variant="outline" onClick={exportExcel}>
              <Download className="mr-2 size-4" /> Export Excel
            </Button>
            {canManage && !category.readonly && (
              <Button onClick={() => setUploadOpen(true)}>
                <Upload className="mr-2 size-4" /> Upload Excel
              </Button>
            )}
            {canManage && category.csvUpload && (
              <Button variant="outline" onClick={() => setCsvOpen(true)}>
                <Upload className="mr-2 size-4" /> Upload CSV
              </Button>
            )}
            {canManage && (
              <Button variant="destructive" onClick={() => setConfirmWipe(true)}>
                <Trash2 className="mr-2 size-4" /> Hapus Semua Data
              </Button>
            )}
          </>
          )
        }

      />

      {(slug === "edc" || slug === "qris") && <CategoryStats slug={slug} />}

      {slug === "edc" && <EdcProduktifTable canEdit={isAdmin} variant="edc" />}
      {slug === "qris" && <EdcProduktifTable canEdit={isAdmin} variant="qris" />}

      {!isCompareResult && !isTimeSeries && !(slug === "edc" || slug === "qris") && (
        <div
          className={cn(
            "mb-5 grid gap-4",
            showValas ? "items-start md:grid-cols-[minmax(0,1fr)_22rem]" : "sm:grid-cols-2 lg:grid-cols-3",
          )}
        >
          <div className={showValas ? "grid gap-4 sm:grid-cols-2" : "contents"}>
            <StatCard
              label={`Jumlah Data · ${category.label}`}
              value={count === null ? "…" : count.toLocaleString("id-ID")}
            />
          </div>
          {showValas && (
            <ValasGiroCard table={dataTable} isAdmin={isAdmin} onCompared={() => setTick((t) => t + 1)} />
          )}
        </div>
      )}

      {category.csvUpload && (
        <div className="mb-4 inline-flex rounded-lg border bg-muted/50 p-1">
          {(["data", "pivot"] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTab(t)}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm transition-colors",
                tab === t ? "bg-card font-medium shadow-card" : "text-muted-foreground",
              )}
            >
              {t === "data" ? "Data" : "Pivot Mutasi Rekening"}
            </button>
          ))}
        </div>
      )}

      {isTimeSeries ? (
        <TimeSeriesView />
      ) : category.csvUpload && tab === "pivot" ? (
        <PivotMutasiView refreshKey={tick} />
      ) : isProduktivitas ? (
        <>
          <ProduktivitasRmftView key={`prod-${tick}`} canEdit={canManage} />
          <AverageGiroView />
          <EdcQrisView cfg={PROD_CFG} title="EDC & QRIS PRODUKTIF" />
          <EdcQrisView cfg={SV_CFG} title="SALES VOLUME EDC & QRIS" />
        </>
      ) : isCompareResult ? (
        <div className="space-y-10">
          <DataTableView
            key={`${slug}-turun-${tick}`}
            title="Penurunan"
            table={`${dataTable}_penurunan`}
            columns={CATEGORY_BY_SLUG.get(`${slug}_penurunan`)?.columns ?? []}
            showDelta
            canEdit={canManage}
            canAdd={false}
            headerOverrides={periods}
          />
          <DataTableView
            key={`${slug}-naik-${tick}`}
            title="Kenaikan"
            table={`${dataTable}_kenaikan`}
            columns={CATEGORY_BY_SLUG.get(`${slug}_kenaikan`)?.columns ?? []}
            showDelta
            canEdit={canManage}
            canAdd={false}
            headerOverrides={periods}
          />
        </div>
      ) : (
        <DataTableView
          key={`${slug}-${tick}`}
          table={dataTable}
          columns={category.columns}
          canEdit={canManage && !category.readonly}
          canAdd={canManage && !category.readonly && !category.noAdd}
          onChanged={() => setTick((t) => t + 1)}
        />
      )}

      <ExcelUploadDialog
        open={uploadOpen}
        onOpenChange={setUploadOpen}
        table={dataTable}
        label={category.label}
        onImported={() => setTick((t) => t + 1)}
      />

      {category.csvUpload && (
        <ExcelUploadDialog
          mode="csv"
          open={csvOpen}
          onOpenChange={setCsvOpen}
          table={dataTable}
          label={category.label}
          onImported={() => setTick((t) => t + 1)}
        />
      )}

      <AlertDialog open={confirmWipe} onOpenChange={setConfirmWipe}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus semua data {category.label}?</AlertDialogTitle>
            <AlertDialogDescription>
              Seluruh baris pada kategori ini akan dihapus permanen.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={wipe}>Hapus Semua</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}